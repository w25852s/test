create definer = root@localhost view cid3 as
select `test`.`tb_category`.`parent_id` AS `parent_id`
from `test`.`tb_category`
group by `test`.`tb_category`.`parent_id`;

